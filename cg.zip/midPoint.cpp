#include <GL/glut.h>
#include <iostream>
using namespace std;

int xc = 250;   
int yc = 250;  
int r  = 10;   


void drawPixel(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

void plotCirclePoints(int xc, int yc, int x, int y)
{
   drawPixel(xc+x,yc+y);
   drawPixel(xc-x,yc+y);
   drawPixel(xc+x,yc-y);
   drawPixel(xc-x,yc-y);
   drawPixel(xc+y,yc+x);
   drawPixel(xc-y,yc+x);
   drawPixel(xc+y,yc-x);
   drawPixel(xc-y,yc-x);

    cout << "(" << xc + x << ", " << yc + y << ")" << endl;
    cout << "(" << xc - x << ", " << yc + y << ")" << endl;
    cout << "(" << xc + x << ", " << yc - y << ")" << endl;
    cout << "(" << xc - x << ", " << yc - y << ")" << endl;
    cout << "(" << xc + y << ", " << yc + x << ")" << endl;
    cout << "(" << xc - y << ", " << yc + x << ")" << endl;
    cout << "(" << xc + y << ", " << yc - x << ")" << endl;
    cout << "(" << xc - y << ", " << yc - x << ")" << endl;

    
}


void midpointCircle()
{
    int x = 0;
    int y = r;
    int p = 1 - r;  

    plotCirclePoints(xc, yc, x, y);

    while (x < y)
    {
        

        if (p < 0)
        {
            p = p + 2 * x + 3;
        }
        else
        {
            y--;
            p = p + 2 * (x - y) + 3;
        }
        x++;

        plotCirclePoints(xc, yc, x, y);
    }
}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0); 
    glPointSize(2.0);

    midpointCircle();

    glFlush();
}


void init()
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    gluOrtho2D(0, 500, 0, 500);
}

int main(int argc, char** argv)
{
    cout << "Midpoint Circle Drawing Algorithm Pixel Coordinates:\n";

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Midpoint Circle Drawing Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}



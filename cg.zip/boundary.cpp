#include <GL/glut.h>
#include <iostream>

int winWidth = 500, winHeight = 500;


float boundaryColor[3] = {0.0, 0.0, 0.0};
float fillColor[3] = {1.0, 0.0, 0.0};


void getPixelColor(int x, int y, float color[3]){
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, color);
}


bool compareColor(float color1[3], float color2[3]){
    return (color1[0] == color2[0] &&
            color1[1] == color2[1] &&
            color1[2] == color2[2]);
}


void boundaryFill(int x, int y){
    float color[3];
    getPixelColor(x, y, color);

    if(!compareColor(color, boundaryColor) && !compareColor(color, fillColor)){
        glColor3fv(fillColor);
        glBegin(GL_POINTS);
            glVertex2i(x, y);
        glEnd();
        glFlush();

        
        boundaryFill(x+1, y);
        boundaryFill(x-1, y);
        boundaryFill(x, y+1);
        boundaryFill(x, y-1);
        boundaryFill(x+1, y+1);
        boundaryFill(x-1, y-1);
        boundaryFill(x+1, y-1);
        boundaryFill(x-1, y+1);
    }
}


void mouse(int button, int state, int x, int y){
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN){
        int winY = winHeight - y; 
        boundaryFill(x, winY);
    }
}

void display(){
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3fv(boundaryColor);
    glLineWidth(3.0);

    glBegin(GL_LINE_LOOP);
        glVertex2i(100, 100);
        glVertex2i(400, 100);
        glVertex2i(400, 400);
        glVertex2i(100, 400);
    glEnd();

    glFlush();
}

void init(){
    glClearColor(1,1,1,1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, winWidth, 0, winHeight);
}

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(winWidth, winHeight);
    glutInitWindowPosition(100,100);
    glutCreateWindow("Boundary Fill Algorithm (8-connected)");

    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse);

    glutMainLoop();
    return 0;
}

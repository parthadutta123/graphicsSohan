#include <GL/glut.h>
#include <cmath> 


const float angleD = 45.0f;

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3){
    glBegin(GL_TRIANGLES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glVertex2f(x3, y3);
    glEnd();
}

void display(){
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glColor3f(1,1,1);

  
    float angleR = angleD * M_PI / 180.0f;
    float cosVal = cos(angleR);
    float sinVal = sin(angleR);

  
    float x1=1, y1=1;
    float x2=3, y2=1;
    float x3=2, y3=3;
    drawTriangle(1.0f,1.0f,3.0f,1.0f,2.0f,3.0f);
   
    float rx1 = x1 * cosVal - y1 * sinVal;
    float ry1 = x1 * sinVal + y1 * cosVal;

    float rx2 = x2 * cosVal - y2 * sinVal;
    float ry2 = x2 * sinVal + y2 * cosVal;

    float rx3 = x3 * cosVal - y3 * sinVal;
    float ry3 = x3 * sinVal + y3 * cosVal;

    drawTriangle(rx1, ry1, rx2, ry2, rx3, ry3);

    glFlush();
}

void init(){
    glClearColor(0,0,0,1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-5,5,-5,5);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500,500);
    glutInitWindowPosition(100,100);
    glutCreateWindow("Triangle Rotation Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <utility>
using namespace std;


void drawLine(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;

    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    float Xinc = dx / (float)steps;
    float Yinc = dy / (float)steps;

    float x = x1;
    float y = y1;

    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; i++) {
        glVertex2i(round(x), round(y));
        x += Xinc;
        y += Yinc;
    }
    glEnd();
}


void drawHELLO() {
    // H
    drawLine(50, 100, 50, 50);
    drawLine(70, 100, 70, 50);
    drawLine(50, 75, 70, 75);

    // E
    drawLine(90, 100, 90, 50);
    drawLine(90, 100, 110, 100);
    drawLine(90, 75, 105, 75);
    drawLine(90, 50, 110, 50);

    // L
    drawLine(130, 100, 130, 50);
    drawLine(130, 50, 150, 50);

    // L
    drawLine(170, 100, 170, 50);
    drawLine(170, 50, 190, 50);

    // O
    drawLine(210, 100, 230, 100);
    drawLine(230, 100, 230, 50);
    drawLine(230, 50, 210, 50);
    drawLine(210, 50, 210, 100);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 0.0); // Yellow color
    drawHELLO();
    glFlush();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 500, 0, 500);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("HELLO using DDA Line Drawing");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}


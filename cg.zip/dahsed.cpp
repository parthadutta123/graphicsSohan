#include <GL/glut.h>
#include <cmath>
using namespace std;

void drawDashDotLine(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;

    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);
    float Xinc = dx / (float)steps;
    float Yinc = dy / (float)steps;

    float x = x1;
    float y = y1;

    int count = 0;

    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; i++) {
        int pattern = count % 10;  
        
        if (pattern <= 4 || pattern == 7)
            glVertex2i(round(x), round(y));
        x += Xinc;
        y += Yinc;
        count++;
    }
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 0.0); // yellow

    drawDashDotLine(50, 100, 450, 100); // horizontal dash-dot line

    glFlush();
}

void init() {
    glClearColor(0,0,0,0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,500,0,500);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Dash-Dot Line using DDA");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}


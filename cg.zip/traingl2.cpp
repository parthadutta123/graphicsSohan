#include <GL/glut.h>
#include <cmath>


float x1 = 1, Y = 1;
float x2 = 3, y2 = 1;
float x3 = 2, y3 = 3;


float angleD = 45.0f;         
float pivotX = 2.0f, pivotY = 2.0f; 

void drawTriangle(float ax1, float ay1, float ax2, float ay2, float ax3, float ay3){
    glBegin(GL_TRIANGLES);
        glVertex2f(ax1, ay1);
        glVertex2f(ax2, ay2);
        glVertex2f(ax3, ay3);
    glEnd();
}

void display(){
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glColor3f(1,1,1);

    
    float rad = angleD * M_PI / 180.0f;
    float cosVal = cos(rad);
    float sinVal = sin(rad);

    // Translate to pivot, rotate, translate back
    float tx1 = x1 - pivotX, ty1 = Y - pivotY;
    float tx2 = x2 - pivotX, ty2 = y2 - pivotY;
    float tx3 = x3 - pivotX, ty3 = y3 - pivotY;

    float rx1 = tx1 * cosVal - ty1 * sinVal + pivotX;
    float ry1 = tx1 * sinVal + ty1 * cosVal + pivotY;

    float rx2 = tx2 * cosVal - ty2 * sinVal + pivotX;
    float ry2 = tx2 * sinVal + ty2 * cosVal + pivotY;

    float rx3 = tx3 * cosVal - ty3 * sinVal + pivotX;
    float ry3 = tx3 * sinVal + ty3 * cosVal + pivotY;

    drawTriangle(rx1, ry1, rx2, ry2, rx3, ry3);

    glFlush();
}

void init(){
    glClearColor(0,0,0,1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,5,0,5); 
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500,500);
    glutInitWindowPosition(100,100);
    glutCreateWindow("Triangle Rotation About Fixed Point");

    init();
    glutDisplayFunc(display);

    glutMainLoop();
    return 0;
}

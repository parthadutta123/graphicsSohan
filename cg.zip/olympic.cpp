#include <GL/glut.h>
#include <iostream>
using namespace std;

// Draw a single pixel
void drawPixel(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

// Plot 8 symmetric points
void plotCirclePoints(int xc, int yc, int x, int y)
{
    drawPixel(xc + x, yc + y);
    drawPixel(xc - x, yc + y);
    drawPixel(xc + x, yc - y);
    drawPixel(xc - x, yc - y);
    drawPixel(xc + y, yc + x);
    drawPixel(xc - y, yc + x);
    drawPixel(xc + y, yc - x);
    drawPixel(xc - y, yc - x);
}

// Midpoint Circle Algorithm
void midpointCircle(int xc, int yc, int radius)
{
    int x = 0;
    int y = radius;
    int p = 1 - radius;

    plotCirclePoints(xc, yc, x, y);

    while (x < y)
    {
        

        if (p < 0)
            p = p + 2 * x + 3;
        else
        {
            y--;
            p = p + 2 * (x - y) + 3;
        }
        x++;

        plotCirclePoints(xc, yc, x, y);
    }
}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glPointSize(2.0);

    int r = 60;

    
    glColor3f(0.0, 0.0, 1.0);        
    midpointCircle(150, 300, r);

    glColor3f(0.0, 0.0, 0.0);       
    midpointCircle(300, 300, r);

    glColor3f(1.0, 0.0, 0.0);        
    midpointCircle(450, 300, r);

    
    glColor3f(1.0, 1.0, 0.0);        
    midpointCircle(225, 220, r);

    glColor3f(0.0, 1.0, 0.0);        
    midpointCircle(375, 220, r);

    glFlush();
}

void init()
{
    glClearColor(1.0, 1.0, 1.0, 0.0);   // White background
    gluOrtho2D(0, 600, 0, 500);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600, 500);
    glutCreateWindow("Olympic Rings - Midpoint Circle Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}


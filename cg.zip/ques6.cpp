#include <GL/glut.h>

int winW = 500, winH = 500;

void init() {
    glClearColor(1,1,1,1);
    glColor3f(0,0,0);
    glPointSize(5);
}

void reshape(int w, int h) {
    winW = w;
    winH = h;

    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);

    glMatrixMode(GL_MODELVIEW);
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        glBegin(GL_POINTS);
        glVertex2i(x, winH - y);  
        glEnd();
        glFlush();
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500,500);
    glutCreateWindow("Mouse Input");

    init();

    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutReshapeFunc(reshape);  

    glutMainLoop();
    return 0;
}


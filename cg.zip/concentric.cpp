#include <GL/glut.h>
#include <iostream>
using namespace std;

int xc = 0;   
int yc = 0;   
int r  ;   


void drawPixel(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

void plotCirclePoints(int xc, int yc, int x, int y)
{
    
    drawPixel(xc + x, yc + y);
    drawPixel(xc - x, yc + y);
    drawPixel(xc + x, yc - y);
    drawPixel(xc - x, yc - y);
    drawPixel(xc + y, yc + x);
    drawPixel(xc - y, yc + x);
    drawPixel(xc + y, yc - x);
    drawPixel(xc - y, yc - x);
}

void midpointCircle(int radius)
{
    int x = 0;
    int y = radius;
    int p = 1 - radius;

    plotCirclePoints(xc, yc, x, y);

    while (x < y)
    {
        

        if (p < 0)
        {
            p = p + 2 * x + 3;
        }
        else
        {
            y--;
            p = p + 2 * (x - y) + 3;
        }
	x++;
        plotCirclePoints(xc, yc, x, y);
    }
}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);
    glPointSize(2.0);

    for(int radius = 20; radius <= r; radius += 20)
    {
        midpointCircle(radius);
    }

    glFlush();
}



void init()
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    gluOrtho2D(-250, 250, -250, 250);
}

int main(int argc, char** argv)
{
    
    cout << "Enter Radius : ";
    cin >> r;
    //cout << "Midpoint Circle Drawing Algorithm Pixel Coordinates:\n";

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Midpoint Circle Drawing Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}


#include <GL/glut.h>
#include <cmath>
#include <iostream>
#include <vector>
using namespace std;


int xStart, yStart, xEnd, yEnd;

void drawLineDDA(int x1, int y1, int x2, int y2)
{
 
    float dx = x2 - x1;
    float dy = y2 - y1;

    float steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    float xInc = dx / steps;
    float yInc = dy / steps;

    float x = x1;
    float y = y1;

    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; i++)
    {
        glVertex2i(round(x), round(y));
        cout << "(" << x << ", " << y << ")\n";
        x += xInc;
        y += yInc;
        
    }
    
    glEnd();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);

    drawLineDDA(xStart, yStart, xEnd, yEnd);

    glFlush();
}

void init()
{
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 500, 0, 500);
}

int main(int argc, char** argv)
{
    cout << "Enter starting point (x y): ";
    cin >> xStart >> yStart;

    cout << "Enter ending point (x y): ";
    cin >> xEnd >> yEnd;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("DDA Line Drawing Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}


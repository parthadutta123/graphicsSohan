#include <GL/glut.h>
#include <cmath>


void drawHouse(float x)
{
    // House Base
    glBegin(GL_LINE_LOOP);
        glVertex2f(x, -100);
        glVertex2f(x + 100, -100);
        glVertex2f(x + 100, 0);
        glVertex2f(x, 0);
    glEnd();

    // Roof
    glBegin(GL_LINE_LOOP);
        glVertex2f(x - 10, 0);
        glVertex2f(x + 110, 0);
        glVertex2f(x + 50, 70);
    glEnd();

    // Door
    glBegin(GL_LINE_LOOP);
        glVertex2f(x + 40, -100);
        glVertex2f(x + 60, -100);
        glVertex2f(x + 60, -40);
        glVertex2f(x + 40, -40);
    glEnd();
}


void drawSun()
{
    glColor3f(1.0, 1.0, 0.0);
    float cx = 200, cy = 150, r = 40;

   
    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < 360; i++)
    {
        float theta = i * 3.1416 / 180;
        glVertex2f(cx + r * cos(theta), cy + r * sin(theta));
    }
    glEnd();

    
    
}


void drawFence()
{
    glColor3f(0.0, 0.0, 0.0);
    for(int i = -320; i <= 320; i += 20)
    {
        glBegin(GL_LINE_LOOP);
            glVertex2f(i, -120);
            glVertex2f(i + 10, -120);
            glVertex2f(i + 10, -60);
            glVertex2f(i, -60);
        glEnd();
    }

    
    glBegin(GL_LINES);
        glVertex2f(-320, -80);
        glVertex2f(320, -80);

        glVertex2f(-320, -100);
        glVertex2f(320, -100);
    glEnd();
}

void drawGround()
{
    glColor3f(0.0, 0.6, 0.0);  

    glBegin(GL_POLYGON);
        glVertex2f(-320, -120);
        glVertex2f(320, -120);
        glVertex2f(320, -240);
        glVertex2f(-320, -240);
    glEnd();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(0.0, 0.0, 0.0);  
    glLineWidth(2.0);

    drawHouse(-250);
    drawHouse(-50);
    drawHouse(150);

    drawSun();
    drawFence();
    //drawGround();
    glFlush();
}

void init()
{
    glClearColor(0.5, 0.8, 1.0, 1.0);  
    gluOrtho2D(-320, 320, -240, 240);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(640, 480);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Three Houses, Sun and Fence - Outline");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}


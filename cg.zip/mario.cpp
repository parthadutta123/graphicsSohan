#include <GL/glut.h>
#include <stdbool.h>

// Mario position
float marioX = 50, marioY = 50;
float velocityY = 0;
bool isJumping = false;

// Platform
float groundY = 30;

// Gravity
float gravity = -0.1f;

// Window size
int width = 800, height = 600;

void init() {
    glClearColor(0.5, 0.8, 1.0, 1.0); // sky blue
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, width, 0, height);
}

void drawRectangle(float x, float y, float w, float h) {
    glBegin(GL_QUADS);
        glVertex2f(x, y);
        glVertex2f(x + w, y);
        glVertex2f(x + w, y + h);
        glVertex2f(x, y + h);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Ground
    glColor3f(0.3, 0.8, 0.3);
    drawRectangle(0, groundY - 20, width, 20);

    // Mario
    glColor3f(1.0, 0.0, 0.0);
    drawRectangle(marioX, marioY, 30, 40);

    glFlush();
}

void update(int value) {
    // Gravity
    if (isJumping) {
        velocityY += gravity;
        marioY += velocityY;

        if (marioY <= groundY) {
            marioY = groundY;
            isJumping = false;
            velocityY = 0;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(16, update, 0); // ~60 FPS
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'a': marioX -= 10; break; // left
        case 'd': marioX += 10; break; // right
        case 'w':
            if (!isJumping) {
                isJumping = true;
                velocityY = 10;
            }
            break;
        case 27: exit(0); // ESC
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(width, height);
    glutCreateWindow("Mini Mario - OpenGL");

    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(0, update, 0);

    glutMainLoop();
    return 0;
}


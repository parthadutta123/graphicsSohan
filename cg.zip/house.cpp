#include <GL/glut.h>
float x1 = 0,Y = 0;
float x2 = 0,y2 = 9;
float x3 = 6,y3 = 9;
float x4 = 6,y4 = 0;
float transX = 5;
void translate(){
	glColor3f(2.0, 0.5, 0.8);
	glBegin(GL_QUADS);
		glVertex2f(x1+transX,Y);
		glVertex2f(x2+transX,y2);
		glVertex2f(x3+transX,y3);
		glVertex2f(x4+transX,y4);
	glEnd();
	glFlush();
	glColor3f(3.0,0.0,0.0); 

  
    	glBegin(GL_TRIANGLES);
        	glVertex2f(0.0f+transX,0.0f+9.0f);
        	glVertex2f(2.0f+transX,0.0f+9.0f);
        	glVertex2f(1.0f+transX,1.0f+9.0f);
    	glEnd();

    glFlush();
}
void display(){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 0.5, 0.8);
    glBegin(GL_QUADS);
        glVertex2f(0.0f,0.0f);
        glVertex2f(0.0f,9.0f);
        glVertex2f(6.0f,9.0f);
        glVertex2f(6.0f,0.0f);
    glEnd();

    glColor3f(1.0,0.0,0.0); 

  
    glBegin(GL_TRIANGLES);
        glVertex2f(0.0f,0.0f);
        glVertex2f(2.0f,0.0f);
        glVertex2f(1.0f,1.0f);
    glEnd();

    glFlush();
    translate();
}

void init(){
    glClearColor(1,1,1,1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,15,0,12);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600,480);
    glutInitWindowPosition(100,100);
    glutCreateWindow("House with Roof");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

#include<GL/glut.h>
void init(){
	glClearColor(0.0,0.0,0.0,1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,500.0,0.0,500.0);
	
}
void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0,1.0,0.0);
	glPointSize(10.0);
	glBegin(GL_TRIANGLES);
	glColor3f( 1, 0, 0 );
	glVertex2f(0.f,300.f);
	glColor3f( 0, 1, 0 );
	glVertex2f(200.f,450.f);
	glColor3f( 0, 0, 1 );
	glVertex2f(400.f,300.f);
	glEnd();
	glFlush();
}
int main(int argc,char** argv){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500,500);
	glutCreateWindow("Draw point Example");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}

#include<GL/glut.h>
#include <glm/glm.hpp>
#include <iostream>
void translate(float x,float y){
	float x2 = 3.0f;
	float y2 = 2.0f;
	float x1 = x + x2;
	float y1 = y + y2;
	glBegin(GL_LINES);
		glVertex2f(x2,y2);
		glVertex2f(x1,y1);
	glEnd();
	glFlush();
}
void rotation(float x,float y){
	float angleD = 30.0f;
	float angleR = glm::radians(angleD);
	float sinVal = glm::sin(angleR);
	float cosVal = glm::cos(angleR);
	float x1 = (x*cosVal) - (y*sinVal);
	float y1 = (x*sinVal) + (y*cosVal);
	glBegin(GL_LINES);
		glVertex2f(0.0f,0.0f);
		glVertex2f(x1,y1);
	glEnd();
	glFlush();
	translate(x1,y1);
}
void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINES);
		glVertex2f(0.0f,0.0f);
		glVertex2f(0.0f,5.0f);
	glEnd();
	glFlush();
	rotation(0.0f,5.0f);
}
void init(){
	glClearColor(0.0,0.0,0.0,1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-10,10,-10,10);
}

int main(int argc,char** argv){
	glutInit(&argc,argv);
	glutCreateWindow("Ladder in openGl");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
	
}

#include<GL/glut.h>
#include <glm/glm.hpp>
#include <iostream>
void reflectY(float x1,float y1,float x2,float y2){
	glBegin(GL_LINES);
		glVertex2f(-x1,y1);
		glVertex2f(-x2,y2);
	glEnd();
	glFlush();
}
void reflectX(float x1,float y1,float x2,float y2){
	glBegin(GL_LINES);
		glVertex2f(x1,-y1);
		glVertex2f(x2,-y2);
	glEnd();
	glFlush();
	reflectY(x1,-y1,x2,-y2);
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINES);
		glVertex2f(2.0f,3.0f);
		glVertex2f(5.0f,1.0f);
	glEnd();
	glFlush();
	reflectX(2.0f,3.0f,5.0f,1.0f);
}
void init(){
	glClearColor(0.0,0.0,0.0,1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-10,10,-10,10);
}

int main(int argc,char** argv){
	glutInit(&argc,argv);
	glutCreateWindow("reflect in openGl");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
	
}

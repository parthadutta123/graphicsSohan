#include <GL/glut.h>
#include <cmath>
#include <iostream>
using namespace std;

int xStart, yStart, xEnd, yEnd;
void drawDottedLine(int x1, int y1, int x2, int y2, int gap = 5) {
    int dx = x2 - x1;
    int dy = y2 - y1;

    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    float Xinc = dx / (float)steps;
    float Yinc = dy / (float)steps;

    float x = x1;
    float y = y1;

    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; i++) {
        
        if (i % gap == 0)
            glVertex2i(round(x), round(y));
        x += Xinc;
        y += Yinc;
    }
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 0.0);

    
    drawDottedLine(xStart, yStart, xEnd, yEnd); 

    glFlush();
}

void init() {
    glClearColor(0,0,0,0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,500,0,500);
}

int main(int argc, char** argv) {
    cout << "Enter starting point (x y): ";
    cin >> xStart >> yStart;

    cout << "Enter ending point (x y): ";
    cin >> xEnd >> yEnd;
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Dotted Line using DDA");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}


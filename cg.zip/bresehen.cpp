#include <GL/glut.h>
#include <cmath>
#include <iostream>
#include<vector>
#include<utility>
using namespace std;


int xStart, yStart, xEnd, yEnd;
void breshenham(int x1, int y1, int x2, int y2)
{
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);

    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;

    int err = dx - dy;   // <-- correct decision parameter

    glBegin(GL_POINTS);
    while (true)
    {
        glVertex2i(x1, y1);
        cout << "(" << x1 << ", " << y1 << ")\n";

        if (x1 == x2 && y1 == y2)
            break;

        int e2 = 2 * err;

        if (e2 > -dy)
        {
            err -= dy;
            x1 += sx;
        }

        if (e2 < dx)
        {
            err += dx;
            y1 += sy;
        }
    }
    glEnd();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);

    breshenham(xStart, yStart, xEnd, yEnd);

    glFlush();
}

void init()
{
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 500, 0, 500);
}

int main(int argc, char** argv)
{
    cout << "Enter starting point (x y): ";
    cin >> xStart >> yStart;

    cout << "Enter ending point (x y): ";
    cin >> xEnd >> yEnd;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("DDA Line Drawing Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}


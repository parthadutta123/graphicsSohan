#include <GL/glut.h>
#include <iostream>

int winWidth = 500, winHeight = 500;

// Colors
float targetColor[3] = {1.0, 1.0, 1.0}; // background (white)
float fillColor[3]   = {1.0, 0.0, 0.0}; // fill (red)

// Function to read pixel color at (x, y)
void getPixelColor(int x, int y, float color[3]){
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, color);
}

// Compare two colors
bool compareColor(float color1[3], float color2[3]){
    return (color1[0] == color2[0] &&
            color1[1] == color2[1] &&
            color1[2] == color2[2]);
}

// 4-connected Flood Fill algorithm
void floodFill(int x, int y){
    float color[3];
    getPixelColor(x, y, color);

    if(compareColor(color, targetColor)){
        // Fill pixel
        glColor3fv(fillColor);
        glBegin(GL_POINTS);
            glVertex2i(x, y);
        glEnd();
        glFlush();

        // Recursively fill neighbors (4-connected)
        floodFill(x+1, y);
        floodFill(x-1, y);
        floodFill(x, y+1);
        floodFill(x, y-1);
    }
}

// Mouse callback to start flood fill
void mouse(int button, int state, int x, int y){
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN){
        int winY = winHeight - y; // OpenGL coordinates conversion
        floodFill(x, winY);
    }
}

// Display function: draw a rectangle to fill
void display(){
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(0.0, 0.0, 0.0); // black rectangle boundary
    glLineWidth(3.0);

    glBegin(GL_LINE_LOOP);
        glVertex2i(100, 100);
        glVertex2i(400, 100);
        glVertex2i(400, 400);
        glVertex2i(100, 400);
    glEnd();

    glFlush();
}

// Initialize OpenGL
void init(){
    glClearColor(1,1,1,1); // white background
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, winWidth, 0, winHeight);
}

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(winWidth, winHeight);
    glutInitWindowPosition(100,100);
    glutCreateWindow("Flood Fill Algorithm");

    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse);

    glutMainLoop();
    return 0;
}

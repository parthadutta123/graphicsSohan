#include<GL/glut.h>

float cube[8][3] = {
    {-0.5, -0.5, -0.5},
    { 0.5, -0.5, -0.5},
    { 0.5,  0.5, -0.5},
    {-0.5,  0.5, -0.5},
    {-0.5, -0.5,  0.5},
    { 0.5, -0.5,  0.5},
    { 0.5,  0.5,  0.5},
    {-0.5,  0.5,  0.5}
};


float translated[8][3];
float tx = 2.0, ty = 1.5, tz = -1.0;
void translateCube(){
	for(int i=0;i<8;i++){
		translated[i][0] = cube[i][0] + tx;
		translated[i][1] = cube[i][1] + ty;
		translated[i][2] = cube[i][2] + tz;
	}
}
void drawCube(float v[8][3]){
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v[0]);
		glVertex3fv(v[1]);
		glVertex3fv(v[2]);
		glVertex3fv(v[3]);
	glEnd();
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v[4]);
		glVertex3fv(v[5]);
		glVertex3fv(v[6]);
		glVertex3fv(v[7]);
	glEnd();
	glBegin(GL_LINES);
		for(int i=0;i<4;i++){
			glVertex3fv(v[i]);
			glVertex3fv(v[i+4]);
		}
	glEnd();
}
void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(4, 4, 6, 0, 0, 0, 0, 1, 0);
	glColor3f(1,1,1);
	drawCube(cube);
	glColor3f(1,0,0);
	drawCube(translated);
	glFlush();
	glutSwapBuffers();
}

void init(){
	glEnable(GL_DEPTH_TEST);
	glClearColor(0,0,0,1);
	translateCube();
}
void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, (float)w / h, 1, 20);

    	glMatrixMode(GL_MODELVIEW);
}
int main(int argc,char** argv){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(800,600);
	glutCreateWindow("3d Cube");
	init();
	glutDisplayFunc(display);
    	glutReshapeFunc(reshape);

    	glutMainLoop();
    	return 0;
}

#include<GL/glut.h>

float pyramid[5][3] = {
    {-0.5, 0.0, -0.5},  
    { 0.5, 0.0, -0.5},
    { 0.5, 0.0,  0.5},
    {-0.5, 0.0,  0.5},
    { 0.0, 1.0,  0.0}   
};

float scaled[5][3];


float sx = 2.0, sy = 1.5, sz = 1.0;
void scalePyramid(){
	for(int i=0;i<5;i++){
		scaled[i][0] = pyramid[i][0]*sx ;
		scaled[i][1] = pyramid[i][1]*sy ;
		scaled[i][2] = pyramid[i][2]*sz ;
	}
}
void drawPyramid(float v[5][3]){
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v[0]);
		glVertex3fv(v[1]);
		glVertex3fv(v[2]);
		glVertex3fv(v[3]);
	glEnd();
	
	glBegin(GL_LINES);
		for(int i=0;i<4;i++){
			glVertex3fv(v[i]);
			glVertex3fv(v[4]);
		}
	glEnd();
}
void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(4, 4, 6, 0, 0, 0, 0, 1, 0);
	glColor3f(1,1,1);
	drawPyramid(pyramid);
	glColor3f(1,0,0);
	drawPyramid(scaled);
	glFlush();
	glutSwapBuffers();
}

void init(){
	glEnable(GL_DEPTH_TEST);
	glClearColor(0,0,0,1);
	scalePyramid();
}
void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, (float)w / h, 1, 20);

    	glMatrixMode(GL_MODELVIEW);
}
int main(int argc,char** argv){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(800,600);
	glutCreateWindow("3d Pyramid");
	init();
	glutDisplayFunc(display);
    	glutReshapeFunc(reshape);

    	glutMainLoop();
    	return 0;
}

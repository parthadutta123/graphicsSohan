#include <GL/glut.h>
#include <stdio.h>

// Clipping window boundaries
float xmin = -1, ymin = -1, xmax = 1, ymax = 1;

// Line endpoints
float x1 = -2, Y = 0.5;
float x2 = 2, y2 = 1.5;

// Region codes
#define INSIDE 0
#define LEFT   1
#define RIGHT  2
#define BOTTOM 4
#define TOP    8

// Function to compute region code
int computeCode(float x, float y) {
    int code = INSIDE;

    if (x < xmin) code |= LEFT;
    else if (x > xmax) code |= RIGHT;
    if (y < ymin) code |= BOTTOM;
    else if (y > ymax) code |= TOP;

    return code;
}

// Cohen–Sutherland clipping
void cohenSutherland(float *x1, float *y1, float *x2, float *y2) {
    int code1 = computeCode(*x1, *y1);
    int code2 = computeCode(*x2, *y2);
    int accept = 0;

    while (1) {
        if ((code1 == 0) && (code2 == 0)) {
            accept = 1;
            break;
        }
        else if (code1 & code2) {
            break;
        }
        else {
            float x, y;
            int codeOut = code1 ? code1 : code2;

            if (codeOut & TOP) {
                x = *x1 + (*x2 - *x1) * (ymax - *y1) / (*y2 - *y1);
                y = ymax;
            }
            else if (codeOut & BOTTOM) {
                x = *x1 + (*x2 - *x1) * (ymin - *y1) / (*y2 - *y1);
                y = ymin;
            }
            else if (codeOut & RIGHT) {
                y = *y1 + (*y2 - *y1) * (xmax - *x1) / (*x2 - *x1);
                x = xmax;
            }
            else if (codeOut & LEFT) {
                y = *y1 + (*y2 - *y1) * (xmin - *x1) / (*x2 - *x1);
                x = xmin;
            }

            if (codeOut == code1) {
                *x1 = x;
                *y1 = y;
                code1 = computeCode(*x1, *y1);
            } else {
                *x2 = x;
                *y2 = y;
                code2 = computeCode(*x2, *y2);
            }
        }
    }

    if (!accept) {
        *x1 = *y1 = *x2 = *y2 = 0;
    }
}

// Display function
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw clipping window
    glColor3f(1, 1, 1);
    glBegin(GL_LINE_LOOP);
        glVertex2f(xmin, ymin);
        glVertex2f(xmax, ymin);
        glVertex2f(xmax, ymax);
        glVertex2f(xmin, ymax);
    glEnd();

    // Draw original line (red)
    glColor3f(1, 0, 0);
    glBegin(GL_LINES);
        glVertex2f(-2, 0.5);
        glVertex2f(2, 1.5);
    glEnd();

    // Perform clipping
    float cx1 = x1, cy1 = Y, cx2 = x2, cy2 = y2;
    cohenSutherland(&cx1, &cy1, &cx2, &cy2);

    // Draw clipped line (green)
    glColor3f(0, 1, 0);
    glBegin(GL_LINES);
        glVertex2f(cx1, cy1);
        glVertex2f(cx2, cy2);
    glEnd();

    glFlush();
}

// Initialization
void init() {
    glClearColor(0, 0, 0, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-3, 3, -3, 3);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Cohen-Sutherland Line Clipping");

    init();
    glutDisplayFunc(display);

    glutMainLoop();
    return 0;
}
